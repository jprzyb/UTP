/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad1;


public interface Selector { // Uwaga: interfejs musi być sparametrtyzowany
}  
