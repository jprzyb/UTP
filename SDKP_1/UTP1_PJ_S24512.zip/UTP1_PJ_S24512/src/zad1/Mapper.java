/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad1;


public interface Mapper { // Uwaga: interfejs musi być sparametrtyzowany
}  
