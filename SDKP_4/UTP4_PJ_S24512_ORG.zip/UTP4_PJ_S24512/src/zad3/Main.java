/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad3;


public class Main {
  public static void main(String[] args) {
  }
}
