package zad3;

public class InputConverter {
}
