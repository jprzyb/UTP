package src.zad2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.concurrent.*;


public class Main extends JFrame {
  private JList<String> taskList;
  private DefaultListModel<String> listModel;
  private ExecutorService executorService;

  public Main() {
    setTitle("Task Manager");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(400, 300);
    setLocationRelativeTo(null);

    listModel = new DefaultListModel<>();
    taskList = new JList<>(listModel);

    JButton addButton = new JButton("Add Task");
    addButton.addActionListener(e -> addTask());

    JButton cancelButton = new JButton("Cancel Task");
    cancelButton.addActionListener(e -> cancelSelectedTask());

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());
    buttonPanel.add(addButton);
    buttonPanel.add(cancelButton);

    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());
    contentPane.add(new JScrollPane(taskList), BorderLayout.CENTER);
    contentPane.add(buttonPanel, BorderLayout.SOUTH);

    executorService = Executors.newFixedThreadPool(5);

    setVisible(true);
  }

  private void addTask() {
    Callable<String> task = () -> {
      // Symulacja wykonywania zadania
      Thread.sleep(3000);
      return "Wynik zadania";
    };

    Future<String> future = executorService.submit(task);
    listModel.addElement("Task " + future.hashCode());

    SwingWorker<String, Void> taskMonitor = new SwingWorker<String, Void>() {
      @Override
      protected String doInBackground() throws Exception {
        while (!future.isDone() && !isCancelled()) {
          // Aktualizacja stanu zadania na liście
          int index = listModel.indexOf("Task " + future.hashCode());
          listModel.set(index, "Task " + future.hashCode() + " (Running)");
          Thread.sleep(500);
        }
        return future.get();
      }

      @Override
      protected void done() {
        Thread A = new Thread(()->{
          try {
            String result = future.get();
            int index = listModel.indexOf("Task " + future.hashCode() + " (Running)");
            listModel.set(index, "Task " + future.hashCode() + " (Completed)");
            JOptionPane.showMessageDialog(Main.this, "Zadanie " + future.hashCode() + " zakończone. Wynik: " + result);
          } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
          }
        });
      }
    };

    taskMonitor.execute();
  }


  private void cancelSelectedTask() {
    int selectedIndex = taskList.getSelectedIndex();
    if (selectedIndex != -1) {
      String taskName = listModel.getElementAt(selectedIndex);
      int taskId = Integer.parseInt(taskName.substring(5, taskName.indexOf(" ")));
      List<Runnable> tasks = executorService.shutdownNow();
      for (Runnable task : tasks) {
        if (((FutureTask<?>) task).hashCode() == taskId) {
          listModel.remove(selectedIndex);
          JOptionPane.showMessageDialog(Main.this, "Zadanie " + taskId + " zostało anulowane.");
          executorService = Executors.newFixedThreadPool(5);
          return;
        }
      }
      JOptionPane.showMessageDialog(Main.this, "Nie można anulować zadania " + taskId + ". Zadanie już zostało zakończone lub nie istnieje.");
    }
  }

  public static void main(String[] args) {
    SwingUtilities.invokeLater(Main::new);
  }
}