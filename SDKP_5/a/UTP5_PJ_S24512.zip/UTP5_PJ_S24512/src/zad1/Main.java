/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad1;


public class Main {

  public static void main(String[] args) {
  }
}
