/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad2;


public class Main {

  public static void main(String[] args) {
  }
}
